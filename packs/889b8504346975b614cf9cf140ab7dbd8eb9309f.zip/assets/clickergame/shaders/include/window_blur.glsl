#ifndef CLICKERGAME_WINDOW_BLUR_GLSL
#define CLICKERGAME_WINDOW_BLUR_GLSL

// ClickerGame: размытие под окном (post_effect/window_blur.json) — проход по x пишет в альфу метку «под затемнением»,
// проход по y размывает только помеченное. Сила — настройка игрока «Размытие меню» (0 — без размытия), радиус — от
// высоты окна: 5 на 1080p — 10 px.

#include <minecraft:globals.glsl>

int windowBlurRadius(vec2 size) {
    return min(int(round(float(MenuBlurRadius) * size.y / 540.0)), 32);
}

float windowBlurWeight(int i, int r) {
    float sigma = float(r) * 0.5;
    return exp(-float(i * i) / (2.0 * sigma * sigma));
}

#endif
