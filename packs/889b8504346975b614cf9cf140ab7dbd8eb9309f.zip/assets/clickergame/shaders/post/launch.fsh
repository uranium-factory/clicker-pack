#version 330
#extension GL_ARB_separate_shader_objects : require

// ClickerGame: запуск ракеты (post_effect/launch.json, ClickerSession#postEffects) — тряска (вектор сдвига до 0.35% высоты,
// 25 Гц, случайно) и шлейф: прошлый кадр (persistent-цель trail) с весом 0.5. Пока trail пустой (после
// очистки альфа 0) — только текущий кадр.

#include <minecraft:globals.glsl>

uniform sampler2D InSampler;
uniform sampler2D PrevSampler;

layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 InSize;
};

layout(location = 0) in vec2 texCoord;

layout(location = 0) out vec4 fragColor;

// n заворачиваем, чтобы sin не получал огромные аргументы; 0.7071 — вектор сдвига не длиннее 0.35% высоты.
vec2 jolt(float n) {
    n = mod(n, 1024.0);
    return (fract(sin(vec2(n * 12.9898, n * 78.233)) * 43758.5453) * 2.0 - 1.0) * 0.7071;
}

void main() {
    // Секунды — GameTime * 1200; толчок — 25 раз в секунду, между толчками — плавно.
    float t = GameTime * 1200.0 * 25.0;
    float n = floor(t);
    vec2 shift = mix(jolt(n), jolt(n + 1.0), t - n) * 0.0035 * InSize.y / InSize;
    vec2 uv = clamp(texCoord + shift, 0.5 / InSize, 1.0 - 0.5 / InSize);
    vec3 cur = texture(InSampler, uv).rgb;
    vec4 prev = texture(PrevSampler, texCoord);
    fragColor = vec4(mix(cur, prev.rgb, 0.5 * prev.a), 1.0);
}
