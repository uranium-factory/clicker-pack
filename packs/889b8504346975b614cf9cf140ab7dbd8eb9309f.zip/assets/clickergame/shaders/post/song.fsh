#version 330
#extension GL_ARB_separate_shader_objects : require

// ClickerGame: краски Песни Сифта на весь мир (post_effect/song_<id>.json, ClickerSession#postEffects). Слабо: песня
// звучит весь мир, худ должен читаться так же. Насыщенность вокруг яркости, потом усиление по каналам, потом подъём
// тёмного (белое остаётся белым).

uniform sampler2D InSampler;

layout(std140) uniform SongConfig {
    vec3 Gain;
    vec3 Lift;
    float Saturation;
};

layout(location = 0) in vec2 texCoord;

layout(location = 0) out vec4 fragColor;

void main() {
    vec3 c = texture(InSampler, texCoord).rgb;
    float luma = dot(c, vec3(0.2126, 0.7152, 0.0722));
    c = (luma + (c - luma) * Saturation) * Gain;
    c += Lift * (1.0 - c);
    fragColor = vec4(clamp(c, 0.0, 1.0), 1.0);
}
