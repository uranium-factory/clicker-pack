#version 330
#extension GL_ARB_separate_shader_objects : require

#include <clickergame:window_blur.glsl>

uniform sampler2D InSampler;
uniform sampler2D DepthSampler;

layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 InSize;
};

layout(location = 0) in vec2 texCoord;

layout(location = 0) out vec4 fragColor;

// Глубина в 26.3 обратная: ближе — больше, даль — 0.
// Глубина затемнения под окном (ClickerSession#dialog) — самая дальняя (меньшая) из углов области 16:9: затемнение на
// весь экран, окно посередине, хоть в одном углу видно само затемнение. Под ним всё в его глубине (оно пишет глубину),
// окно, тосты и курсор — ближе.
// ponytail: с «Улучшенной прозрачностью» (OIT) полупрозрачное затемнение глубину не пишет — размоется только самое
// дальнее в углах; нужна точность — затемнению непрозрачный двойник глубины.
float dimDepth() {
    float aspect = InSize.x / InSize.y;
    float fit = min(1.0, aspect / 1.7777778);
    vec2 corner = 0.5 * 0.97 * vec2(1.7777778 * fit / aspect, fit);
    float d = 1.0;
    for (int i = 0; i < 4; i++) {
        vec2 uv = 0.5 + corner * vec2((i & 1) == 0 ? -1.0 : 1.0, (i & 2) == 0 ? -1.0 : 1.0);
        d = min(d, texelFetch(DepthSampler, ivec2(uv * InSize), 0).r);
    }
    return d;
}

void main() {
    ivec2 p = ivec2(texCoord * InSize);
    vec3 own = texelFetch(InSampler, p, 0).rgb;
    float dim = dimDepth() + 1e-5;
    int r = windowBlurRadius(InSize);
    if (r == 0 || texelFetch(DepthSampler, p, 0).r > dim) {
        fragColor = vec4(own, 0.0);
        return;
    }
    vec3 sum = vec3(0.0);
    float total = 0.0;
    int last = int(InSize.x) - 1;
    for (int i = -r; i <= r; i++) {
        ivec2 q = ivec2(clamp(p.x + i, 0, last), p.y);
        if (texelFetch(DepthSampler, q, 0).r <= dim) {
            float w = windowBlurWeight(i, r);
            sum += texelFetch(InSampler, q, 0).rgb * w;
            total += w;
        }
    }
    fragColor = vec4(sum / total, 1.0);
}
