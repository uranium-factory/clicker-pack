#version 330
#extension GL_ARB_separate_shader_objects : require

// ClickerGame: лихорадка (post_effect/fever.json, ClickerSession#postEffects) — золотое свечение по краям экрана:
// полоса 12% высоты, у самого края 0.35, мягкое мерцание 0.8 Гц (±25%). Центр (руда) чистый.

#include <minecraft:globals.glsl>

uniform sampler2D InSampler;

layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 InSize;
};

layout(location = 0) in vec2 texCoord;

layout(location = 0) out vec4 fragColor;

void main() {
    vec3 c = texture(InSampler, texCoord).rgb;
    vec2 p = texCoord * InSize;
    float edge = min(min(p.x, InSize.x - p.x), min(p.y, InSize.y - p.y)) / InSize.y;
    float mask = 1.0 - smoothstep(0.0, 0.12, edge);
    // Секунды — GameTime * 1200; за 1200 с — целое число периодов, на сбросе GameTime мерцание не скачет.
    float strength = 0.35 * (1.0 + 0.25 * sin(6.2831853 * fract(GameTime * 1200.0 * 0.8)));
    fragColor = vec4(mix(c, vec3(1.0, 0.78, 0.25), mask * strength), 1.0);
}
