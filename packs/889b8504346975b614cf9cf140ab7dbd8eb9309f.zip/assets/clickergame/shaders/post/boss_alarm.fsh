#version 330
#extension GL_ARB_separate_shader_objects : require

// ClickerGame: тревога мирового босса, до конца боя ≤ 10 с (post_effect/boss_alarm.json, ClickerSession#postEffects) —
// красная виньетка сердцебиением: двойной удар раз в секунду (1 Гц), мягкие горбы без резких пиков, у края 0.35 на
// ударе и 0.20 между, полоса 25% высоты. Центр (руда) чистый.

#include <minecraft:globals.glsl>

uniform sampler2D InSampler;

layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 InSize;
};

layout(location = 0) in vec2 texCoord;

layout(location = 0) out vec4 fragColor;

// Удар — мягкий горб: растёт и спадает по 0.15 с (период 1 с) вокруг вершины в at.
float beat(float phase, float at) {
    return 1.0 - smoothstep(0.0, 0.15, abs(phase - at));
}

void main() {
    vec3 c = texture(InSampler, texCoord).rgb;
    vec2 p = texCoord * InSize;
    float edge = min(min(p.x, InSize.x - p.x), min(p.y, InSize.y - p.y)) / InSize.y;
    float mask = 1.0 - smoothstep(0.0, 0.25, edge);
    // Секунды — GameTime * 1200; за 1200 с — целое число ударов (1 Гц), на сбросе GameTime ритм не скачет. «Тук-тук», пауза.
    float phase = fract(GameTime * 1200.0);
    float strength = mix(0.20, 0.35, max(beat(phase, 0.15), beat(phase, 0.45)));
    fragColor = vec4(mix(c, vec3(0.85, 0.05, 0.05), mask * strength), 1.0);
}
