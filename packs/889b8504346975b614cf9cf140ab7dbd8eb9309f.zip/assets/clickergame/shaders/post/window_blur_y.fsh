#version 330
#extension GL_ARB_separate_shader_objects : require

#include <clickergame:window_blur.glsl>

uniform sampler2D InSampler;

layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 InSize;
};

layout(location = 0) in vec2 texCoord;

layout(location = 0) out vec4 fragColor;

// Проход по x оставил в альфе метку: 1 — под затемнением (размыть), 0 — окно и что над ним (как есть).
void main() {
    ivec2 p = ivec2(texCoord * InSize);
    vec4 own = texelFetch(InSampler, p, 0);
    if (own.a < 0.5) {
        fragColor = vec4(own.rgb, 1.0);
        return;
    }
    int r = windowBlurRadius(InSize);
    vec3 sum = vec3(0.0);
    float total = 0.0;
    int last = int(InSize.y) - 1;
    for (int i = -r; i <= r; i++) {
        vec4 s = texelFetch(InSampler, ivec2(p.x, clamp(p.y + i, 0, last)), 0);
        if (s.a >= 0.5) {
            float w = windowBlurWeight(i, r);
            sum += s.rgb * w;
            total += w;
        }
    }
    fragColor = vec4(sum / total, 1.0);
}
