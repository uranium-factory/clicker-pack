#version 330
#extension GL_ARB_separate_shader_objects : require

// ClickerGame: вспышка на весь экран (post_effect/flash_<цвет>_<n>.json, tools/post_effects.py) — к цвету на n/8;
// сервер ставит n = 8 и каждый тик снимает по 1.

uniform sampler2D InSampler;

layout(std140) uniform FlashConfig {
    vec3 Color;
    float Amount;
};

layout(location = 0) in vec2 texCoord;

layout(location = 0) out vec4 fragColor;

void main() {
    vec3 c = texture(InSampler, texCoord).rgb;
    fragColor = vec4(mix(c, Color, Amount), 1.0);
}
