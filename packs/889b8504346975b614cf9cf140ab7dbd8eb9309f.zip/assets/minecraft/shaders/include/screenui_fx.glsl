#ifndef SCREENUI_FX_GLSL
#define SCREENUI_FX_GLSL

// ClickerGame: backdrops of the mine (tools/backdrops.py) come alive here. A backdrop pixel carries its effect code in
// the low two bits of red (low) and blue (high): 0 - none, 1 wave, 2 lava, 3 lava fall, 4 water, 5 flicker, 6 star,
// 7 embers, 8 portal particles, 9 dust, 10 spores, 11 sculk souls, 12 bubbles, 13 heat haze, 14 fire, 15 end portal
// star field (the Sift gate). Not in alpha: a texture with alpha other than 0/255 is drawn in the late translucent
// pass, after the dialog dim has written depth over it, and vanishes behind the dim. Backdrop models carry the tint
// SCREENUI_BACKDROP_TINT, so icons are never decoded.
// Read with texelFetch at mip 0, so mipmaps never blend the marks. Glow, sun rays and grading are baked in.

#include <minecraft:globals.glsl>

float screenui_hash(vec2 p) {
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}

// One particle per grid cell of g texels; the field slides by v texels a second, each particle sways sideways.
float screenui_particles(vec2 tc, float t, float g, vec2 v, float radius, float density) {
    vec2 p = tc - v * t;
    vec2 cell = floor(p / g);
    if (screenui_hash(cell + 17.0) > density) {
        return 0.0;
    }
    vec2 at = (cell + 0.2 + 0.6 * vec2(screenui_hash(cell), screenui_hash(cell + 7.1))) * g;
    at.x += sin(t * 0.9 + screenui_hash(cell + 3.3) * 6.28) * 2.0;
    float twinkle = 0.55 + 0.45 * sin(t * 3.0 + screenui_hash(cell + 9.2) * 6.28);
    return smoothstep(radius, radius * 0.4, length(p - at)) * twinkle;
}

int screenui_code(vec4 texel) {
    ivec3 bits = ivec3(texel.rgb * 255.0 + 0.5) & 3;
    return bits.r | bits.b << 2;
}

// The texel dx to the side, if it carries the same effect; otherwise the texel's own colour. A plant is baked over
// the dark back wall, so a texel of the wall pulled into its edge would show as a black hole in the leaf.
vec3 screenui_shifted(sampler2D tex, vec2 tc, float dx, vec3 own, int code) {
    vec4 s = texelFetch(tex, ivec2(tc + vec2(dx, 0.0)), 0);
    return s.a < 1.0 || screenui_code(s) != code ? own : s.rgb;
}

// tools/backdrops.py TINT.
const vec3 SCREENUI_BACKDROP_TINT = vec3(254.0 / 255.0);

// Colours of the vanilla end portal layers (rendertype_end_portal.fsh).
const vec3 SCREENUI_PORTAL[15] = vec3[](
    vec3(0.022087, 0.098399, 0.110818), vec3(0.011892, 0.095924, 0.089485), vec3(0.027636, 0.101689, 0.100326),
    vec3(0.046564, 0.109883, 0.114838), vec3(0.064901, 0.117696, 0.097189), vec3(0.063761, 0.086895, 0.123646),
    vec3(0.084817, 0.111994, 0.166380), vec3(0.097489, 0.154120, 0.091064), vec3(0.106152, 0.131144, 0.195191),
    vec3(0.097721, 0.110188, 0.187229), vec3(0.133516, 0.138278, 0.148582), vec3(0.070006, 0.243332, 0.235792),
    vec3(0.196766, 0.142899, 0.214696), vec3(0.047281, 0.315338, 0.321970), vec3(0.204675, 0.390010, 0.302066)
);

// The Sift gate's star field (code 15; tools/make_pack.py gate): the vanilla end portal - layers of specks in screen
// space, each turned its own way and drifting at its own pace, so the field stays put while the gate turns. A speck is
// a pixel of a 300 px tall screen whatever the window; the texel's own colour is the dark base under the specks.
vec3 screenui_portal(vec3 base, float t) {
    vec2 p = floor(gl_FragCoord.xy / ScreenSize.y * 300.0) + 0.5;
    vec3 c = base;
    for (int i = 0; i < 15; i++) {
        float l = float(i + 1);
        float a = radians((l * l * 4321.0 + l * 9.0) * 2.0);
        vec2 q = mat2(cos(a), -sin(a), sin(a), cos(a)) * p / (1.0 + (15.0 - l) * 0.1)
                + vec2(17.0 / l, (2.0 + l / 1.5) * t * 0.5) * 9.0;
        float h = screenui_hash(floor(q) + l * 31.7);
        if (h > 0.9965) {
            c += SCREENUI_PORTAL[i] * (2.0 + 1500.0 * (h - 0.9965));
        }
    }
    return c;
}

vec4 screenui_backdrop(sampler2D tex, vec2 uv, vec4 color, vec4 tint) {
    vec2 tc = uv * vec2(textureSize(tex, 0));
    vec4 raw = texelFetch(tex, ivec2(tc), 0);
    if (raw.a == 0.0) {
        discard;
    }
    if (any(greaterThan(abs(tint.rgb - SCREENUI_BACKDROP_TINT), vec3(0.5 / 255.0))) || raw.a < 1.0) {
        return color;
    }
    int code = screenui_code(raw);
    if (code < 1 || code > 15) {
        return color;
    }
    float t = GameTime * 1200.0;
    if (code == 15) {
        return vec4(screenui_portal(raw.rgb, t), 1.0);
    }
    vec2 block = floor(tc / 16.0);
    vec3 c = raw.rgb;
    if (code == 1) {
        // Vines and leaves sway by up to a texel, each block on its own beat.
        float s = sin(t * 1.6 + block.x * 1.3 + block.y * 0.7 + tc.y * 0.08);
        c = screenui_shifted(tex, tc, floor(s * 1.6 + 0.5), c, 1);
    } else if (code == 2) {
        // Lava pool: one slow swell rolls across the surface (a single wave, so no checkerboard).
        c *= 0.94 + 0.1 * sin(tc.x * 0.12 - tc.y * 0.04 - t * 1.4);
    } else if (code == 3) {
        // Lava fall: the texture slides down, every block of the fall in step. The sprite may sit off the 16-texel
        // grid of the atlas, so read from the fall itself: above its top, take the same texel one block lower.
        vec2 at = vec2(tc.x, max(0.0, tc.y - mod(t * 12.0, 16.0)));
        vec4 s = texelFetch(tex, ivec2(at), 0);
        if (screenui_code(s) != 3) {
            s = texelFetch(tex, ivec2(at + vec2(0.0, 16.0)), 0);
        }
        c = screenui_code(s) == 3 ? s.rgb : c;
        c *= 0.92 + 0.12 * sin(tc.y * 0.13 - t * 4.0);
    } else if (code == 4 || code == 12) {
        float sp = pow(max(0.0, sin(tc.x * 0.15 + t * 1.5) * sin(tc.y * 0.5 - t * 2.3 + tc.x * 0.03)), 10.0);
        c = c * (0.95 + 0.08 * sin(tc.x * 0.2 + t * 2.0)) + vec3(0.55, 0.8, 1.0) * sp * 0.6;
    } else if (code == 5) {
        float h = screenui_hash(block) * 6.28;
        c *= 1.0 + 0.14 * sin(t * 3.1 + h) + 0.06 * sin(t * 7.3 + h * 2.0);
    } else if (code == 14) {
        // Fire: tongues sway more toward their tips, bright bands run up the flame, the block flickers.
        float h = screenui_hash(block) * 6.28;
        float tip = 1.0 - fract(tc.y / 16.0);
        float s = sin(t * 5.0 + h + tc.y * 0.35) * (0.4 + 1.6 * tip);
        c = screenui_shifted(tex, tc, floor(s + 0.5), c, 14);
        c *= 0.9 + 0.22 * sin(tc.y * 0.7 + t * 9.0 + h + sin(tc.x * 0.5 + t * 2.0))
                + 0.08 * sin(t * 7.3 + h * 2.0);
    } else if (code == 6) {
        c *= 0.35 + 0.65 * (0.5 + 0.5 * sin(t * 2.4 + screenui_hash(floor(tc)) * 6.28));
    }
    if (code == 13) {
        // Heat over lava: the wall wobbles, embers rise.
        c = screenui_shifted(tex, tc, floor(sin(t * 5.0 + tc.y * 0.4) * 1.2 + 0.5), c, 13);
    }
    if (code == 7 || code == 13) {
        c += vec3(1.0, 0.6, 0.15) * screenui_particles(tc, t, 22.0, vec2(0.0, -14.0), 1.6, 0.35);
        c = mix(c, vec3(0.45, 0.42, 0.4), screenui_particles(tc, t, 30.0, vec2(3.0, 6.0), 1.2, 0.25) * 0.6);
    } else if (code == 8) {
        c += vec3(0.82, 0.45, 1.0) * screenui_particles(tc, t, 24.0, vec2(1.0, -4.0), 1.5, 0.35);
    } else if (code == 9) {
        c = mix(c, vec3(0.92, 0.88, 0.78), screenui_particles(tc, t, 28.0, vec2(1.0, -1.5), 1.1, 0.3) * 0.35);
    } else if (code == 10) {
        c += vec3(0.7, 0.95, 0.45) * screenui_particles(tc, t, 26.0, vec2(1.5, -3.0), 1.3, 0.3) * 0.8;
    } else if (code == 11) {
        c += vec3(0.25, 0.85, 0.9) * screenui_particles(tc, t, 26.0, vec2(0.0, -6.0), 1.4, 0.3);
    } else if (code == 12) {
        float b = screenui_particles(tc, t, 24.0, vec2(0.0, -18.0), 1.8, 0.35);
        c = mix(c, vec3(0.85, 0.95, 1.0), b * 0.7);
    }
    return vec4(c, 1.0);
}

#endif
