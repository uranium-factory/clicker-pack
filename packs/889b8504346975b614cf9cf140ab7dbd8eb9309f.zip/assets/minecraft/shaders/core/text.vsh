#version 330
#extension GL_ARB_separate_shader_objects : require

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#include <minecraft:fog.glsl>
#include <minecraft:sample_lightmap.glsl>
#endif

#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>
#include <minecraft:globals.glsl>

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;
layout(location = 2) in vec2 UV0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
layout(location = 3) in ivec2 UV2;
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
uniform sampler2D Sampler2;
layout(location = 0) out float sphericalVertexDistance;
layout(location = 1) out float cylindricalVertexDistance;
#endif

layout(location = 2) out vec4 vertexColor;
layout(location = 3) out vec2 texCoord0;

// ScreenUI pack-cursor: the cursor is marked by its background color - R 1, G = its colour slot (254 fill,
// 253 outline, 247-252 the cursor palette, see UiSession.CursorColor), B = cursor x range * 64,
// A = 127 + sensitivity / 0.0005 - and follows the head rotation every frame. Since 26.3 text backgrounds are drawn
// by this shader (text_background is gone).
bool screenui_byte(float c, float b) {
    return abs(c * 255.0 - b) < 0.5;
}

bool screenui_cursor() {
    float g = Color.g * 255.0;
    return screenui_byte(Color.r, 1.0) && g > 246.5 && g < 254.5;
}

// The cursor palette - the same colours as UiSession.CursorColor.
vec3 screenui_palette(int slot) {
    if (slot == 254) return vec3(255.0, 255.0, 255.0) / 255.0;
    if (slot == 253) return vec3(12.0, 12.0, 16.0) / 255.0;
    if (slot == 252) return vec3(138.0, 90.0, 43.0) / 255.0;
    if (slot == 251) return vec3(90.0, 58.0, 26.0) / 255.0;
    if (slot == 250) return vec3(111.0, 230.0, 207.0) / 255.0;
    if (slot == 249) return vec3(42.0, 157.0, 138.0) / 255.0;
    if (slot == 248) return vec3(201.0, 255.0, 244.0) / 255.0;
    return vec3(252.0, 212.0, 58.0) / 255.0;
}

vec4 screenui_recolor(vec4 lit) {
    if (!screenui_cursor()) {
        return lit;
    }
    return vec4(screenui_palette(int(Color.g * 255.0 + 0.5)) * lit.g / Color.g, 1.0);
}

// ScreenUI: the screen is drawn as if the client's FOV were 70, whatever the setting.
// Screen displays have light block 15 / sky 14 (UV2 = 240, 224) and sit 0.5-2 blocks in front of the camera.
// pack-cursor: light block 15 / sky 13 (UV2 = 240, 208) - the player looks at the screen with their own eyes and
// turns their head freely. The screen (0.3-3 blocks south of the camera) is drawn from a fixed camera that faces
// south at FOV 70, whatever the head rotation; its 16:9 area always fits the window (a narrower one shrinks it).
vec4 screenui_fov(vec4 clip) {
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    if (ProjMat[3][3] == 0.0) {
        if (UV2 == ivec2(240, 224) && clip.w > 0.5 && clip.w < 2.0) {
            clip.xy *= 1.4281480 / ProjMat[1][1]; // 1 / tan(70 deg / 2)
        } else if (UV2 == ivec2(240, 208) && Position.z > 0.3 && Position.z < 3.0
                && abs(Position.x) < 8.0 && abs(Position.y) < 6.0) {
            float aspect = ProjMat[1][1] / ProjMat[0][0];
            float fit = min(1.0, aspect / 1.7777778); // 16:9
            vec3 v = vec3(-Position.x, Position.y, -Position.z);
            clip = vec4(v.x * 1.4281480 * fit / aspect, v.y * 1.4281480 * fit,
                        ProjMat[2][2] * v.z + ProjMat[3][2], ProjMat[2][3] * v.z);
            if (screenui_cursor()) {
                vec4 mark = Color * 255.0;
                float sensitivity = (mark.a - 127.0) * 0.0005;
                float range = mark.b / 64.0;
                float yaw = degrees(atan(-ModelViewMat[2][0], -ModelViewMat[0][0]));
                float pitch = degrees(asin(clamp(ModelViewMat[1][2], -1.0, 1.0)));
                // F5, вид спереди: камера смотрит на игрока — её поворот обратный повороту головы. Голову сервер
                // держит в ±85° от экрана, так что камера дальше 90° — это вид спереди.
                if (abs(yaw) > 90.0) {
                    yaw = yaw > 0.0 ? yaw - 180.0 : yaw + 180.0;
                    pitch = -pitch;
                }
                vec2 at = clamp(vec2(yaw, -pitch) * sensitivity, vec2(-range, -1.1), vec2(range, 1.1));
                clip.xy += vec2(at.x / aspect, at.y) * fit / 1.1 * clip.w;
                // Курсор стоит в плоскости экрана (Screen.CURSOR_Z), а глубину берёт на 0.7 ближе — поверх окон и
                // объёмных моделей, но без параллакса с кнопками, если камера чуть сдвинута.
                float near = v.z + 0.7;
                clip.z = (ProjMat[2][2] * near + ProjMat[3][2]) / (ProjMat[2][3] * near) * clip.w;
            }
        }
    }
#endif
    return clip;
}

#ifdef IS_GUI
// Таб на весь экран (TabCanvas): свой глиф помечен цветом — младший полубайт R = 7, G = 9 (фон) или 10 (текст и
// иконки: строки футера 30–59, поднимаются на высоту холста), B — режим: 0–8 — сдвиг вниз, 14 — скрыть (распорка),
// 15 — на всё окно. Холст 480×270 px вписывается в окно целым масштабом по центру.
const vec2 TAB_CANVAS = vec2(480.0, 270.0);
// Первая строка футера: без шапки и строк игроков (PlayerTabOverlay: 10 + 0 · 9 + 1).
const float TAB_TOP = 11.0;
// Фон на всё окно — полупрозрачный: игра под табом затемнена, панели холста поверх (размыть кадр из GUI нельзя).
const float TAB_DIM = 0.8;

bool tab_marked(ivec3 c) {
    return (c.r & 15) == 7 && ((c.g & 15) == 9 || (c.g & 15) == 10);
}

float tab_channel(int v) {
    int hi = v & 240;
    return hi == 240 ? 1.0 : float(hi | 8) / 255.0;
}

vec4 tab_position(vec3 pos, int mode, bool top) {
    if (mode == 14) {
        return vec4(-2.0, -2.0, 0.0, 1.0);
    }
    // Размер окна в px GUI; знак [1][1] у Vulkan и OpenGL разный.
    vec2 gui = 2.0 / abs(vec2(ProjMat[0][0], ProjMat[1][1]));
    float scale = ScreenSize.x / gui.x;
    vec2 at;
    if (mode == 15) {
        // Угол квада — по месту вершины, не по её номеру (номер у клиента ненадёжен): фон — блок 64×9 px в начале
        // первой строки холста, левые вершины у x 240, правые у 304, верхние у y 0, нижние у 9.
        vec2 c = vec2(pos.x - floor(gui.x / 2.0) + TAB_CANVAS.x / 2.0, pos.y - TAB_TOP);
        at = step(vec2(272.0, 4.5), c) * gui;
    } else {
        vec2 c = vec2(pos.x - floor(gui.x / 2.0) + TAB_CANVAS.x / 2.0,
                      pos.y - TAB_TOP - (top ? TAB_CANVAS.y : 0.0) + float(mode));
        float k = max(1.0, floor(min(ScreenSize.x / TAB_CANVAS.x, ScreenSize.y / TAB_CANVAS.y)));
        at = (floor((ScreenSize - TAB_CANVAS * k) / 2.0) + c * k) / scale;
    }
    return ProjMat * ModelViewMat * vec4(at, pos.z, 1.0);
}
#endif

void main() {
#ifdef IS_GUI
    ivec3 mark = ivec3(round(Color.rgb * 255.0));
    if (tab_marked(mark)) {
        gl_Position = tab_position(Position, mark.b & 15, (mark.g & 15) == 10);
        vertexColor = vec4(tab_channel(mark.r), tab_channel(mark.g), tab_channel(mark.b),
                           (mark.b & 15) == 15 ? TAB_DIM : Color.a);
        texCoord0 = UV0;
        return;
    }
#endif
    gl_Position = screenui_fov(ProjMat * ModelViewMat * vec4(Position, 1.0));

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = screenui_recolor(Color * sample_lightmap(Sampler2, UV2));
#else
    vertexColor = Color;
#endif
    texCoord0 = UV0;
}
