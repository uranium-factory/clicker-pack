#version 330
#extension GL_ARB_separate_shader_objects : require

#ifdef GLINT
#include <minecraft:globals.glsl>
#endif
#include <minecraft:fog.glsl>
#include <minecraft:dynamictransforms.glsl>
#include <minecraft:oit.glsl>
#include <minecraft:screenui_fx.glsl>

uniform sampler2D Sampler0;

#ifdef GLINT
uniform sampler2D GlintSampler;
#endif

#ifndef OIT_ALPHA_ONLY
layout(location = 0) in float sphericalVertexDistance;
layout(location = 1) in float cylindricalVertexDistance;
#endif
layout(location = 2) in vec4 vertexColor;
#ifndef OIT_ALPHA_ONLY
layout(location = 3) in vec4 lightMapColor;
layout(location = 4) in vec4 overlayColor;
#endif
layout(location = 5) in vec2 texCoord0;
#ifdef GLINT
layout(location = 6) in vec2 texCoordGlint;
#endif

#ifndef OIT_ALPHA_ONLY
layout(location = 0) out vec4 fragColor;
#endif

layout(location = 8) in vec3 screenuiView;
layout(location = 9) flat in int screenuiLit;

// ScreenUI: light of a screen element by its surface normal - taken from how the view-space position changes
// between neighbour pixels, so it is right whatever space the vertex normals are in. The side facing the viewer:
// a flat icon gets full brightness, a block a lighter top and darker sides, as in the inventory.
float screenui_light() {
    vec3 n = normalize(cross(dFdx(screenuiView), dFdy(screenuiView)));
    if (dot(n, screenuiView) > 0.0) {
        n = -n;
    }
    float light = max(0.0, dot(normalize(vec3(-0.4, 1.0, 0.7)), n)) + max(0.0, dot(normalize(vec3(0.4, 1.0, 0.7)), n));
    return min(1.0, light * 0.6 + 0.4);
}

#ifndef OIT_ALPHA_ONLY
vec4 calculateFinalColor(vec4 color) {
    color.rgb = mix(overlayColor.rgb, color.rgb, overlayColor.a);
    color *= lightMapColor;

    #ifdef GLINT
    vec4 glintColor = GlintAlpha * texture(GlintSampler, texCoordGlint);// Glint color modulator?
    // Matches BlendFuntion.GLINT
    color.rgb += glintColor.rgb * glintColor.rgb;
    #endif

    #ifdef OIT_ACCUMULATE
    color = sampleColorForAccumulation(color);
    vec4 fogColor = vec4(FogColor.rgb * color.a, FogColor.a);
    #else
    vec4 fogColor = FogColor;
    #endif

    return apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, fogColor);
}
#endif

void main() {
    float screenuiShade = screenui_light();
    vec4 color = texture(Sampler0, texCoord0);
    // ClickerGame: the mine backdrops come alive (screenui_fx.glsl).
    if (screenuiLit == 1) {
        color = screenui_backdrop(Sampler0, texCoord0, color, vertexColor);
    }
    #ifdef ALPHA_CUTOUT
    if (color.a < ALPHA_CUTOUT) {
        discard;
    }
    #endif

    color *= vertexColor * ColorModulator;
    if (screenuiLit == 1) {
        color.rgb *= screenuiShade;
    }

    #ifdef GLINT
    color.a = max(color.a, GlintAlpha);
    #endif

    #ifdef OIT_ALPHA_ONLY
    executeAlphaOnlyPhase(gl_FragCoord.z, color.a);
    #else
    fragColor = calculateFinalColor(color);
    #endif
}
