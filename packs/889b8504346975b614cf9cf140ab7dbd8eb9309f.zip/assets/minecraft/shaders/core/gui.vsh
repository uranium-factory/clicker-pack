#version 330
#extension GL_ARB_separate_shader_objects : require

// Can't moj_import in things used during startup, when resource packs don't exist.
// This is a copy of dynamicimports.glsl and projection.glsl
layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    mat4 TextureMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
};
layout(std140) uniform Projection {
    mat4 ProjMat;
};

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;

layout(location = 0) out vec4 vertexColor;

// ClickerGame, таб на весь экран (core/text.vsh, TabCanvas): у футера нулевой ширины ванильная подложка — чёрная
// полупрозрачная полоса (Integer.MIN_VALUE) ±12 px от середины экрана во всю высоту футера; сквозь затемнение под
// табом она видна. Такая заливка не рисуется: альфа 0 — gui.fsh её отбрасывает. Подложки обычного таба шире (по
// ширине текста) и остаются.
bool tab_backdrop(vec3 pos, vec4 color) {
    if (ivec4(round(color * 255.0)) != ivec4(0, 0, 0, 128)) {
        return false;
    }
    float center = floor(1.0 / abs(ProjMat[0][0])); // половина ширины GUI
    return abs(pos.x - center) <= 13.0 && pos.y >= 8.0;
}

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    vertexColor = tab_backdrop(Position, Color) ? vec4(0.0) : Color;
}
